#!/usr/bin/env bash
set -euo pipefail
gradle :app:assembleDebug
