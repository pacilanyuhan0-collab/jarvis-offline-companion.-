package com.jarvis.offline

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var db: KnowledgeBase
    private lateinit var tts: TextToSpeech
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private var ttsReady = false
    private val speechRequest = 42
    private val audioPermissionRequest = 43

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = KnowledgeBase(this)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 16)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 28f
            setTextColor(0xFF45D5FF.toInt())
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "OFFLINE MINECRAFT BEDROCK ASSISTANT • ${db.count()} KNOWLEDGE ENTRIES"
            textSize = 11f
            setTextColor(0xFF9AB6C8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        chat = TextView(this).apply {
            text = "Systems online. I can answer common Minecraft Bedrock questions without internet.\n\nTry: How do I make a Nether portal?"
            textSize = 16f
            setTextColor(0xFFEAF7FF.toInt())
            setPadding(16, 16, 16, 16)
            setBackgroundColor(0xFF102235.toInt())
        }
        val scroll = ScrollView(this).apply { addView(chat) }
        input = EditText(this).apply {
            hint = "Ask JARVIS..."
            setHintTextColor(0xFF7893A7.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(true)
        }
        val ask = Button(this).apply { text = "ASK JARVIS"; setOnClickListener { ask(input.text.toString()) } }
        val voice = Button(this).apply { text = "🎙 SPEAK"; setOnClickListener { startVoice() } }
        val speak = Button(this).apply { text = "🔊 READ ANSWER"; setOnClickListener { speakLast() } }
        val bubble = Button(this).apply { text = "ENABLE FLOATING BUBBLE"; setOnClickListener { enableBubble() } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(voice, LinearLayout.LayoutParams(0, -2, 1f)); addView(speak, LinearLayout.LayoutParams(0, -2, 1f)) }
        root.addView(title)
        root.addView(sub)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(ask)
        root.addView(row)
        root.addView(bubble)
        setContentView(root)
    }

    private fun ask(text: String) {
        if (text.isBlank()) return
        val answer = db.answer(text)
        chat.text = "YOU: $text\n\nJARVIS: $answer"
        input.setText("")
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        launchVoiceRecognizer()
    }

    private fun launchVoiceRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { Toast.makeText(this, "Speech recognition is not installed. Try an offline speech service.", Toast.LENGTH_LONG).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            launchVoiceRecognizer()
        } else if (requestCode == audioPermissionRequest) {
            Toast.makeText(this, "Microphone permission is needed for voice input.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(spoken)
            ask(spoken)
            speakLast()
        }
    }

    private fun speakLast() {
        if (!ttsReady) {
            Toast.makeText(this, "Text-to-speech is still starting. Check Android offline voice settings.", Toast.LENGTH_SHORT).show()
            return
        }
        val text = chat.text.toString().substringAfter("JARVIS: ", chat.text.toString())
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-answer")
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Allow display over other apps, then tap Enable Floating Bubble again.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, BubbleService::class.java))
        Toast.makeText(this, "JARVIS bubble enabled. Tap it to open the assistant.", Toast.LENGTH_SHORT).show()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.getDefault()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
