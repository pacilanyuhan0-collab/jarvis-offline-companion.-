package com.jarvis.offline

import android.content.Context
import org.json.JSONArray
import java.util.Locale

data class Knowledge(val category: String, val question: String, val answer: String)

class KnowledgeBase(context: Context) {
    private val items: List<Knowledge> = context.assets.open("knowledge.json").bufferedReader().use { reader ->
        val array = JSONArray(reader.readText())
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            Knowledge(obj.getString("category"), obj.getString("question"), obj.getString("answer"))
        }
    }

    fun count() = items.size

    fun answer(query: String): String {
        val q = query.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ")
        val words = q.split(Regex("\\s+")).filter { it.length > 2 }.toSet()
        if (words.isEmpty()) return "Ask me a Minecraft Bedrock question, such as crafting, mobs, commands, redstone, or survival."
        val ranked = items.map { item ->
            val hay = (item.question + " " + item.category + " " + item.answer).lowercase(Locale.ROOT)
            val titleWords = item.question.lowercase(Locale.ROOT).split(Regex("\\W+")).toSet()
            val score = words.sumOf { w -> (if (w in titleWords) 4 else 0) + (if (hay.contains(w)) 1 else 0) }
            item to score
        }.maxByOrNull { it.second }
        return if (ranked == null || ranked.second < 2) {
            "I couldn't find a close match in my offline Minecraft database. Try shorter keywords like 'Nether portal', 'villager trades', 'redstone repeater', or 'diamond mining'."
        } else "${ranked.first.answer}\n\nTopic: ${ranked.first.category}"
    }
}
