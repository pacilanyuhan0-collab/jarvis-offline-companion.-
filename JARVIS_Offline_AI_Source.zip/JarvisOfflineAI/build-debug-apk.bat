@echo off
gradle :app:assembleDebug
