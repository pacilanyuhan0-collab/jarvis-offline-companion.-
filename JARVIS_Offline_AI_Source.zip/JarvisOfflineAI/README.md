# JARVIS Offline AI — Android Studio project

An offline-first Minecraft Bedrock helper for Android. The app bundles `knowledge.json` with 500 Q&A entries and performs keyword matching locally. It includes Android speech recognition (requests offline mode), Android TextToSpeech, and an optional floating overlay bubble.

## Build the APK
1. Install Android Studio (current stable) with Android SDK Platform 35 and a compatible JDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin/Kotlin plugin if needed.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

This delivery environment does not include the Android SDK or Gradle, so a compiled APK could not be produced here. The project is ready to open and build in Android Studio; this ZIP is the source project, not an installable APK.

## Install and permissions
- Install the generated APK on Android.
- Open JARVIS and tap **Enable Floating Bubble**.
- Android opens the overlay permission screen. Allow “Display over other apps”, return to JARVIS, and tap the button again.
- Tap the floating **J** bubble to reopen the app. Long-press the bubble to dismiss it.

## Offline voice
- Voice input uses Android's speech-recognition service with `EXTRA_PREFER_OFFLINE=true`. Android may still use an online recognizer if the selected service ignores this preference.
- For offline speech, install an offline language pack for your chosen language in Android Settings → System / Languages & input → Speech recognition (wording varies by phone).
- Text-to-speech uses the device's installed TTS engine and selected voice. Download an offline voice in Android Text-to-speech settings.
- Voice support and offline language availability vary by manufacturer, Android version, language, and installed speech service.

## Scope and limitations
- This is a local FAQ assistant, not a large generative AI model. It finds the closest matching entry in its 500-entry bundled database.
- Minecraft recipes, commands, and mechanics can change between versions. Verify version-sensitive details in-game.
- The floating bubble is an overlay and requires explicit Android permission. Android battery/background restrictions may stop it on some devices.
- No network permission is declared; the bundled knowledge lookup works without internet.

## Project structure
- `app/src/main/assets/knowledge.json` — 500 local knowledge entries.
- `MainActivity.kt` — chat UI, speech input, and speech output.
- `KnowledgeBase.kt` — offline local search.
- `BubbleService.kt` — floating overlay bubble.
